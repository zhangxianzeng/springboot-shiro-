# project
project 公开项目，供大家使用，快速上手；并附上博客链接，详细描述使用方法和注意事项； 项目中的技术框架稳定版本不定时更新，欢迎关注；

项目中的技术框架稳定版本不定时更新，欢迎关注；

**项目说明**：   
[ **wyait-common** ](https://github.com/wyait/project.git) : 通用工具类；  
[ **wyait-redis** ](https://github.com/wyait/project.git)：[spring boot 1.5.9整合redis;包含redis封装的API工具类和缓存管理的注解配置和使用；http://blog.51cto.com/wyait/2048478](http://blog.51cto.com/wyait/2048478)；  
[ **spring-redis** ](https://github.com/wyait/project.git)：[spring整合redis;包含redis封装的API工具类和缓存管理的配置、使用和注意事项；http://blog.51cto.com/wyait/2049866](http://blog.51cto.com/wyait/2049866)；  
[ **wyait-manage** ](https://github.com/wyait/project.git)：[spring boot + mybatis + shiro + layui 搭建的后台权限管理系统；http://blog.51cto.com/wyait/2082803](http://blog.51cto.com/wyait/2082803)；
