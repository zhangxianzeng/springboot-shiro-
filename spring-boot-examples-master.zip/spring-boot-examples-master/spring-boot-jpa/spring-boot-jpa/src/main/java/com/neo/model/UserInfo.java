package com.neo.model;

public interface UserInfo {
	String getUserName();
	String getEmail();
	String getHobby();
	String getIntroduction();
}