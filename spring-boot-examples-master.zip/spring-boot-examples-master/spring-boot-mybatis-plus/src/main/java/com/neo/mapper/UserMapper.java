package com.neo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.neo.model.User;

public interface UserMapper extends BaseMapper<User> {

}