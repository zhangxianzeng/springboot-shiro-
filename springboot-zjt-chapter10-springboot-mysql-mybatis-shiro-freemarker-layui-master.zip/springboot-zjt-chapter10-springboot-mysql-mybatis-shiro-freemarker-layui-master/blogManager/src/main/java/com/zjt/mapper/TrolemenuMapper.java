package com.zjt.mapper;

import com.zjt.entity.Trolemenu;
import com.zjt.util.MyMapper;

public interface TrolemenuMapper extends MyMapper<Trolemenu> {
}