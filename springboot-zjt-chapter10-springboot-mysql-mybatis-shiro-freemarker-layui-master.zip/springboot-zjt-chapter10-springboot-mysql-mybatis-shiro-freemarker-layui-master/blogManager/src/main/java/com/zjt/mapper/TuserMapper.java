package com.zjt.mapper;

import com.zjt.entity.Tuser;
import com.zjt.util.MyMapper;

public interface TuserMapper extends MyMapper<Tuser> {
}