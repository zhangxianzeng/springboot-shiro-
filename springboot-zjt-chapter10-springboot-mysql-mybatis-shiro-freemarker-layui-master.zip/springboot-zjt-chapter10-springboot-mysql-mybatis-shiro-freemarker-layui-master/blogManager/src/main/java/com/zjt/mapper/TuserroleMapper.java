package com.zjt.mapper;

import com.zjt.entity.Tuserrole;
import com.zjt.util.MyMapper;

public interface TuserroleMapper extends MyMapper<Tuserrole> {
}