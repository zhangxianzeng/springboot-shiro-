package com.zjt.service;

import com.zjt.entity.Trolemenu;

public interface TrolemenuService extends IService<Trolemenu>{
}