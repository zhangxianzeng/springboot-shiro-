package com.zjt.service;

import com.zjt.entity.Tuser;

public interface TuserService  extends IService<Tuser>{
}