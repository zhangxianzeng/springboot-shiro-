package com.zjt.service;

import com.zjt.entity.Tuserrole;

public interface TuserroleService extends IService<Tuserrole>{
}