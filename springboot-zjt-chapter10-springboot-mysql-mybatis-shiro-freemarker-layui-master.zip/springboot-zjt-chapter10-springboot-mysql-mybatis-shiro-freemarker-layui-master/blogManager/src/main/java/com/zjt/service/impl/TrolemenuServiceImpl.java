package com.zjt.service.impl;

import com.zjt.entity.Trolemenu;
import com.zjt.service.TrolemenuService;
import org.springframework.stereotype.Service;

/**
 * @author <a href=""mailto:zhaojt@gtmap.cn></a>
 * @version 1.0, 2017/11/10
 * @description
 */
@Service("trolemenuService")
public class TrolemenuServiceImpl   extends BaseService<Trolemenu> implements TrolemenuService {

}
