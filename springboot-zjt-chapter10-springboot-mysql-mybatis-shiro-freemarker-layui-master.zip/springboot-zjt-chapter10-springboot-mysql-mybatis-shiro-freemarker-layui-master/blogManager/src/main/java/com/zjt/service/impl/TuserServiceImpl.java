package com.zjt.service.impl;

import com.zjt.entity.Tuser;
import com.zjt.service.TuserService;
import org.springframework.stereotype.Service;

/**
 * @author <a href=""mailto:zhaojt@gtmap.cn></a>
 * @version 1.0, 2017/11/10
 * @description
 */
@Service("tuserService")
public class TuserServiceImpl   extends BaseService<Tuser> implements TuserService {

}
