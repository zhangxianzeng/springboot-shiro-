package com.zjt.service.impl;

import com.zjt.entity.Tuserrole;
import com.zjt.service.TuserroleService;
import org.springframework.stereotype.Service;

/**
 * @author <a href=""mailto:zhaojt@gtmap.cn></a>
 * @version 1.0, 2017/11/10
 * @description
 */
@Service("tuserroleService")
public class TuserroleServiceImpl   extends BaseService<Tuserrole>  implements TuserroleService {

}
